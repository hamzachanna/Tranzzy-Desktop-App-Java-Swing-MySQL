import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

public class LoginPage extends JFrame {
    public static String adminUsername = "Admin";
    public static String adminPassword = "ADMIN@123";

    LoginPage() {

        setTitle("Login");
        setBounds(0, 0, 1920, 1080);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setResizable(false);

        JPanel leftPanel = new JPanel();
        leftPanel.setBackground(new Color(121, 164, 176));
        leftPanel.setLayout(null);
        leftPanel.setBounds(0, 0, 480, 1080);
        add(leftPanel);

        JPanel image = new JPanel();
        image.setBounds(81, 25, 291, 291);
        image.setLayout(new BorderLayout());
        ImageIcon logo = new ImageIcon(getClass().getResource("Logo.png"));
        JLabel imageLabel = new JLabel(logo);
        image.setBackground(null);
        image.add(imageLabel);
        leftPanel.add(image);

        JPanel bodyPanel = new JPanel();
        bodyPanel.setLayout(null);
        bodyPanel.setBounds(480, 0, 1440, 1080);
        add(bodyPanel);

        JPanel headingPanel = new JPanel();
        headingPanel.setLayout(null);
        headingPanel.setBounds(0, 80, 1440, 180);
        bodyPanel.add(headingPanel);

        JLabel mainHeading = new JLabel("tranzzy");
        mainHeading.setBounds(138, 20, 300, 52);
        mainHeading.setForeground(new Color(75, 129, 144));
        mainHeading.setFont(new Font("Krona One", Font.BOLD, 42));
        headingPanel.add(mainHeading);

        JLabel header = new JLabel("Login");
        header.setBounds(138, 80, 300, 52);
        header.setForeground(new Color(75, 129, 144));
        header.setFont(new Font("Krona One", Font.PLAIN, 22));
        headingPanel.add(header);

        JLabel enterDetails = new JLabel("Enter login details to continue");
        enterDetails.setBounds(138, 114, 360, 52);
        enterDetails.setForeground(new Color(121, 164, 176));
        enterDetails.setFont(new Font("Krona One", Font.PLAIN, 16));
        headingPanel.add(enterDetails);


        JPanel EditTextPanel = new JPanel();
        EditTextPanel.setLayout(null);
        EditTextPanel.setBounds(0, 250, 1440, 200);
        bodyPanel.add(EditTextPanel);

        JLabel username = new JLabel("Enter Username");
        username.setBounds(138, 0, 200, 30);
        username.setForeground(new Color(138, 182, 194));
        username.setFont(new Font("Krona One", Font.PLAIN, 14));
        EditTextPanel.add(username);

        JTextField nameField = new JTextField();
        nameField.setBounds(138, 36, 400, 50);
        nameField.setOpaque(false);
        nameField.setBorder(BorderFactory.createLineBorder(new Color(138, 182, 194), 4));
        nameField.setForeground(new Color(75, 129, 144));
        nameField.setFont(new Font("Krona One", Font.PLAIN, 16));
        EditTextPanel.add(nameField);

        JLabel password = new JLabel("Enter Password");
        password.setBounds(138, 100, 200, 30);
        password.setForeground(new Color(138, 182, 194));
        password.setFont(new Font("Krona One", Font.PLAIN, 14));
        EditTextPanel.add(password);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(138, 136, 400, 50);
        passwordField.setOpaque(false);
        passwordField.setBorder(BorderFactory.createLineBorder(new Color(138, 182, 194), 4));
        passwordField.setForeground(new Color(75, 129, 144));
        passwordField.setEchoChar('•');
        passwordField.setFont(new Font("Krona One", Font.PLAIN, 16));
        EditTextPanel.add(passwordField);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(null);
        buttonPanel.setBounds(0, 100, 1440, 1300);
        bodyPanel.add(buttonPanel);

        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("Krona One", Font.PLAIN, 14));
        loginButton.setBounds(270, 360, 120, 40);
        loginButton.setBorder(null);
        loginButton.setForeground(Color.WHITE);
        loginButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String givenUsername = nameField.getText();
                String givenPassword = new String(passwordField.getPassword());

                if (givenUsername.equals(adminUsername) && givenPassword.equals(adminPassword)) {
                    dispose();
                    new AdminPanel();
                    return;
                }
                if(login(givenUsername,givenPassword)){
                    dispose();
                    new MainMenu();
                }
                else{
                    JOptionPane.showMessageDialog(null,"Invalid Credentials","Try Again",JOptionPane.ERROR_MESSAGE);
                }

            }
        });
        loginButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                loginButton.setBackground(new Color(167, 210, 221));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                loginButton.setBackground(new Color(138, 182, 194));
            }
        });
        loginButton.setBackground(new Color(138, 182, 194));
        buttonPanel.add(loginButton);

        JLabel goToRegister = new JLabel("New to tranzzy ? ");
        goToRegister.setBounds(250, 420, 300, 50);
        goToRegister.setForeground(new Color(138, 182, 194));
        goToRegister.setFont(new Font("Krona One", Font.PLAIN, 14));
        buttonPanel.add(goToRegister);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(270, 480, 120, 40);
        registerButton.setFont(new Font("Krona One", Font.PLAIN, 14));
        registerButton.setForeground(new Color(121,164,176));
        registerButton.setBorder(null);
        registerButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        registerButton.addActionListener(new ActionListener() {
            @Override public void actionPerformed(ActionEvent e) {
                dispose();
                new RegisterPage();
            }
        });
        registerButton.setBackground(Color.white);
        registerButton.setOpaque(false);
        buttonPanel.add(registerButton);

        setExtendedState(JFrame.MAXIMIZED_BOTH);


        setVisible(true);
    }

    public static void main(String[] args) {
        new LoginPage();
    }

    public static boolean login(String username, String password) {

        try {
            Connection connection = DriverManager.getConnection(Main.urlSQL, Main.usernameSQL, Main.passwordSQL);
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM users;";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String gottenUsername = resultSet.getString("name");
                String gottenPassword = resultSet.getString("password");
                int gottenUserID = resultSet.getInt("user_id");

                if (username.equals(gottenUsername) && password.equals(gottenPassword)) {
                    User.userID=gottenUserID;
                    User.username=gottenUsername;
                    User.password=gottenPassword;
                    return true;
                }
            }
        } catch (SQLException exception) {
            JOptionPane.showMessageDialog(null,exception.getMessage(),"404",JOptionPane.QUESTION_MESSAGE);
        }
        return false;
    }
}

