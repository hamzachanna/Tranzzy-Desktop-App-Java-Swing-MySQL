import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

public class RegisterPage extends JFrame {
    RegisterPage(){
        setTitle("Register");
        setBounds(-10,0,1920,1080);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setResizable(false);

        JPanel rightPanel=new JPanel();
        rightPanel.setBackground(new Color(121,164,176));
        rightPanel.setLayout(null);
        rightPanel.setBounds(802,0,480,1080);
        add(rightPanel);

        JPanel image =new JPanel();
        image.setBounds(81,25,291,291);
        image.setLayout(new BorderLayout());
        ImageIcon logo=new ImageIcon(getClass().getResource("Logo.png"));
        JLabel imageLabel=new JLabel(logo);
        image.setBackground(null);
        image.add(imageLabel);
        rightPanel.add(image);

        JPanel bodyPanel=new JPanel();
        bodyPanel.setLayout(null);
        bodyPanel.setBounds(0,0,1440,1080);
        add(bodyPanel);

        JPanel headingPanel=new JPanel();
        headingPanel.setLayout(null);
        headingPanel.setBounds(0,50,1440,180);
        bodyPanel.add(headingPanel);

        JLabel mainHeading=new JLabel("tranzzy");
        mainHeading.setBounds(138,20,300,52);
        mainHeading.setForeground(new Color(75, 129, 144));
        mainHeading.setFont(new Font("Krona One",Font.BOLD,42));
        headingPanel.add(mainHeading);

        JLabel header=new JLabel("Register");
        header.setBounds(138,80,300,52);
        header.setForeground(new Color(75, 129, 144));
        header.setFont(new Font("Krona One",Font.PLAIN,22));
        headingPanel.add(header);

        JLabel enterDetails=new JLabel("Enter details to create account");
        enterDetails.setBounds(138,114,360,52);
        enterDetails.setForeground(new Color(121,164,176));
        enterDetails.setFont(new Font("Krona One",Font.PLAIN,16));
        headingPanel.add(enterDetails);

        JPanel EditTextPanel=new JPanel();
        EditTextPanel.setLayout(null);
        EditTextPanel.setBounds(0,220,1440,300);
        bodyPanel.add(EditTextPanel);

        JLabel username=new JLabel("Create Username");
        username.setBounds(138,2,200,30);
        username.setForeground(new Color(138, 182, 194));
        username.setFont(new Font("Krona One",Font.PLAIN,14));
        EditTextPanel.add(username);

        JTextField nameField=new JTextField();
        nameField.setBounds(138,38,400,50);
        nameField.setOpaque(false);
        nameField.setBorder(BorderFactory.createLineBorder(new Color(138, 182, 194),4));
        nameField.setForeground(new Color(75, 129, 144));
        nameField.setFont(new Font("Krona One",Font.PLAIN,16));
        EditTextPanel.add(nameField);

        JLabel password=new JLabel("Create Password");
        password.setBounds(138,102,200,30);
        password.setForeground(new Color(138, 182, 194));
        password.setFont(new Font("Krona One",Font.PLAIN,14));
        EditTextPanel.add(password);

        JPasswordField passwordField=new JPasswordField();
        passwordField.setBounds(138,138,400,50);
        passwordField.setOpaque(false);
        passwordField.setBorder(BorderFactory.createLineBorder(new Color(138,182,194),4));
        passwordField.setForeground(new Color(75, 129, 144));
        passwordField.setEchoChar('•');
        passwordField.setFont(new Font("Krona One",Font.PLAIN,16));
        EditTextPanel.add(passwordField);

        JLabel confirm=new JLabel("Confirm Password");
        confirm.setBounds(138,202,200,30);
        confirm.setForeground(new Color(138, 182, 194));
        confirm.setFont(new Font("Krona One",Font.PLAIN,14));
        EditTextPanel.add(confirm);

        JPasswordField confirmPassword=new JPasswordField();
        confirmPassword.setBounds(138,238,400,50);
        confirmPassword.setOpaque(false);
        confirmPassword.setBorder(BorderFactory.createLineBorder(new Color(138,182,194),4));
        confirmPassword.setForeground(new Color(75, 129, 144));
        passwordField.setEchoChar('•');
        confirmPassword.setFont(new Font("Krona One",Font.PLAIN,16));
        EditTextPanel.add(confirmPassword);

        JPanel buttonPanel=new JPanel();
        buttonPanel.setLayout(null);
        buttonPanel.setBounds(-10,100,1440,1300);
        bodyPanel.add(buttonPanel);

        JButton registerButton =new JButton("Register");
        registerButton.setFont(new Font("Krona One",Font.PLAIN,14));
        registerButton.setBounds(270,438,120,40);
        registerButton.setForeground(Color.WHITE);
        registerButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username=nameField.getText();
                String userPassword=new String(passwordField.getPassword());
                String userConfirmPassword=new String(confirmPassword.getPassword());

                if(userPassword.equals(userConfirmPassword)){
                    boolean isUnique=true;
                        try{
                            Connection connection=DriverManager.getConnection(Main.urlSQL,Main.usernameSQL,Main.passwordSQL);
                            Statement statement=connection.createStatement();
                            ResultSet resultSet=statement.executeQuery("SELECT * FROM users;");
                            while(resultSet.next()){
                                if(username.equals(resultSet.getString("name"))){
                                    isUnique = false;
                                    break;
                                }
                            }
                        }catch(Exception exception){
                            JOptionPane.showMessageDialog(null,exception.getMessage(),"404",JOptionPane.QUESTION_MESSAGE);
                        }
                        if(!isUnique){
                            JOptionPane.showMessageDialog(null, "This Username Already Exists","Try Another",JOptionPane.WARNING_MESSAGE);
                        }else {
                            if(register(username,userPassword)){
                                JOptionPane.showMessageDialog(null, "Account Created Successfully, Login Now","Success",JOptionPane.PLAIN_MESSAGE);
                            }
                            else{
                                JOptionPane.showMessageDialog(null,"Error Occurred","404",JOptionPane.QUESTION_MESSAGE);
                            }
                            dispose();
                            new LoginPage();
                        }

                }else{
                    JOptionPane.showMessageDialog(null,"Password mismatched","Try Again",JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        registerButton.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseEntered(MouseEvent e){
                registerButton.setBackground(new Color(167, 210, 221));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                registerButton.setBackground(new Color(138,182,194));
            }
        });

        registerButton.setBackground(new Color(138,182,194));
        buttonPanel.add(registerButton);

        JLabel goToLogin=new JLabel("Already have an account ? ");
        goToLogin.setBounds(220,476,300,50);
        goToLogin.setForeground(new Color(138, 182, 194));
        goToLogin.setFont(new Font("Krona One",Font.PLAIN,12));
        buttonPanel.add(goToLogin);


        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("Krona One", Font.PLAIN, 14));
        loginButton.setBounds(270, 520, 120, 40);
        loginButton.setForeground(new Color(121,164,176));
        loginButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        loginButton.addActionListener(new ActionListener() {
            @Override public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginPage();
            }
        });
        loginButton.setBackground(Color.white);
        loginButton.setOpaque(false);
        buttonPanel.add(loginButton);

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }
    public static boolean register(String username, String password) {

        try {
            Connection connection = DriverManager.getConnection(Main.urlSQL, Main.usernameSQL, Main.passwordSQL);
            Statement statement = connection.createStatement();
            String query = "INSERT INTO users (name,password) VALUES ('"+username+"','"+password+"');";
            int rows= statement.executeUpdate(query);
            if(rows>0){
                return true;
            }
        } catch (SQLException exception) {
            JOptionPane.showMessageDialog(null,exception.getMessage(),"404",JOptionPane.QUESTION_MESSAGE);
        }
        return false;
    }
    public static void main(String[] args) {
        new RegisterPage();
    }
}